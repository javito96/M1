'use strict'

function BinarioADecimal(num) {
  // tu codigo aca

}

function DecimalABinario(num) {
  // tu codigo aca

}


module.exports = {
  BinarioADecimal,
  DecimalABinario,
}